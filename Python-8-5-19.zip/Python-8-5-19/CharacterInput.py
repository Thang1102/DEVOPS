#!/usr/bin/python3
name = input("What your name: ")
age  = int(input("How old are you:"))
year = str((2014-age)+100)
obj = str(name +" will be 100 years old in the year "+ year+ '\n')
print(4 * obj)