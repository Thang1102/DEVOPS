#!/usr/bin/python3
num = int(input("Input num:"))
check = int(input("Input check:"))

if num %4 == 0 :
	print(num, "is a multiple of 4")
elif num % 2 == 0:
	print(num, "is a even number")
else:
	print(num, "is a odd number")

#divides
if num % check == 0:
	print(num, "divides evenly by", check)
else:
	print(num, "does not divides evenly by", check)