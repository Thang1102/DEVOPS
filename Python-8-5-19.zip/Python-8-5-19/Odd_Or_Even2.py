#!/usr/bin/python3
num = int(input("Input number: "))
mod = num % 2
if mod > 0:
	print(num," is odd number")
else:
	print(num," is even number")