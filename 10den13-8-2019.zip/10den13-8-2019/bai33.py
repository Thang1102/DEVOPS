#!/usr/bin/python3
if __name__=='__main__':
	datebirth_dictionary = {
	"Father": '30/08/1969',
	"Mother": '30/12/1971',
	"Thang": '11/02/1998',
	"Loi": '07/12/2001'
	}

	Input_name =  input("What is your name? ")
	Output_datebirth = datebirth_dictionary[Input_name]
	print("The birthday of",Input_name,"is",Output_datebirth)

