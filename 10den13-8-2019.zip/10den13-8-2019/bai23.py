#!/usr/bin/python3
import random
#write a file

fw1 = open("one.txt","w")
for i in range(1000):
        number = random.randrange(1, 500)
        number = str(number)
        fw1.write(number)
        fw1.write('\n')
    


