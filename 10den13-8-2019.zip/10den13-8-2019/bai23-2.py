#!/usr/bin/python3
import random

fw2=open("other.txt","w")
for j in range(1000):
	num = random.randrange(1,600)
	content = str(num)
	fw2.write(content)
	fw2.write("\n")
