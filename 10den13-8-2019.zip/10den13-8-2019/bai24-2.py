#!/usr/bin/python3
def drawboard(dump):
	dump = int(dump)
	i = 0
	das = "--- "
	ver = '|  '
	das = das * (dump -1)
	ver = ver * (dump+1)
	while i < (dump+1):
		print(das)
		if i != dump:
			print(ver)
		i+=1
if __name__ == "__main__":
	dumpsize = int(input("draw size: "))
	drawboard(dumpsize)