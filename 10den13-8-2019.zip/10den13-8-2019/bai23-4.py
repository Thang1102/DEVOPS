#!/usr/bin/python

def freadfile(filename):
	list_num = []
	with open(filename) as fo:
		line = fo.readline()
		while line:
			list_num.append(int(line))
			line = fo.readline()
	return list_num

one_list = freadfile('one.txt')
other_list = freadfile('other.txt')
   
overLap = [elem for elem in one_list if elem in other_list]
print(overLap)



	
	
		
