#!/usr/bin/python3
def num_max(a,b,c):
	max_num = a
	if max_num < b:
		max_num = b
	if max_num < c:
		max_num = c
	return max_num

input_a = int(input('You Input number a: '))
input_b = int(input('You Input number b: '))
input_c = int(input('You Input number c: '))	

d = num_max(input_a,input_b,input_c)
print("max number is: ",str(d) )