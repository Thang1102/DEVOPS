#!/usr/bin/python3

one_list=[]
with open('one.txt') as one_file:
	line=one_file.readline()
	while line:
		one_list.append(int(line))
		line=one_file.readline()

other_list=[]
with open('other.txt') as other_file:
	line=other_file.readline()
	while line:
		other_list.append(int(line))
		line=other_file.readline()

overlaplist = []
for i in one_list:
	if i in other_list:
		overlaplist.append(i)
		
print(overlaplist)