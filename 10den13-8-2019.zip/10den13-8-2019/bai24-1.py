#!/usr/bin/python3

def print_dash():
	print("--- " * (size-1))

def print_vertical():
	print("|  " * (size+1))

if __name__ == "__main__":
   size = int(input("What size of game board? "))
   for i in range(size):
   	print_dash()
   	print_vertical()
   print(print_dash())
    