#!/usr/bin/python3
import random

a = random.sample(range(5,30),10)
b = random.sample(range(5,30),12)

list_overlap=[i for i in set(a) if i in b]
List =[]
for num in list_overlap:
	if num not in List:
		List.append(num)
print(List)
	