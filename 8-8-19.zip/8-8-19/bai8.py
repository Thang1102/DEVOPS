#!/user/bin/python3
# Rock Paper Scissors
import sys
u1 = input('what your name ?: ')
u2 = input('And your name? :')
user1_choose=input("%s, Ban chon keo,giay hay da ? " %u1)
user2_choose=input("%s, Ban chon keo,giay hay da ? " %u2)

def compare(u1,u2):
	if u1==u2:
		return("Hoa!")
	elif u1=='keo':
		if u2=='giay':
			return("Keo thang!")
		else:
			return("Da thang")
	elif u1=="da":
		if u2=='keo':
			return('Da thang')
		else:
			return('Giay thang')
	elif u1=='giay':
		if u2=='da':
			return('Giay thang')
		else:
			return('Keo thang')
	else:
		return('No input!')
		sys.exit()
print(compare(user1_choose,user2_choose))

