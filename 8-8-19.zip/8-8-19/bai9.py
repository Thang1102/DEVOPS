#!/usr/bin/python3
import random

a = random.randint(1,9)
guess = 0
count = 0

while guess != a and guess != 'exit':

	guess = input('You can input a number for game Guess: ')
	
	if guess =='exit':
		print('Bye Bye !')
		break
	else:
		guess = int(guess)
		count +=1
		if guess > a:
			print('too high')
		elif guess < a:
			print('too low')
		else:
			print("You got it!\n")
			print("And it only took you ",count," tries!")
        	


