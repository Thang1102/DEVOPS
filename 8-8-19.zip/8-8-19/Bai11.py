#!/usr/bin/python3
number_check = int(input('Please you can input a number: '))
check = [i for i in range(1,number_check) if number_check % i == 0]

def check_prime(n):
	if number_check > 1:
		if len(check) > 1:
			print(str(number_check),' Not prime!')
		else:
			print(str(number_check),' Prime!')
	else:
		print(str(number_check),' Not prime!')
check_prime(number_check)
	