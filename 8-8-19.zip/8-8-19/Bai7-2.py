#!/usr/bin/python3
import random
new_list=[]
list_leng=random.randint(10,50)

while len(new_list) < list_leng:
	new_list.append(random.randint(11,40))

even_list=[num for num in new_list if num % 2 == 0]

print(new_list)
print(even_list)

