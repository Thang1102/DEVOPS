#!/usr/bin/python3

wrd=str(input("Please input word: "))
reverse = wrd[::-1]
print(reverse)
if wrd!=reverse:
	print('This word is not a palindrome ')
else:
	print("This word is a palindrome")