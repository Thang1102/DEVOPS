#!/usr/bin/python
_author_='Thang'

num =  int(input('Input a number for check: '))
listRange = list(range(1,num+1))
divisorList=[]
for i in listRange:
	if num % i == 0:
		divisorList.append(i)
print(divisorList)

