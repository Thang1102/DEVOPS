#!/usr/bin/python3
def reverse(wrd):
	x = ''
	for i in range(len(wrd)):
		x += wrd[len(wrd)-1-i]
		return x

wrd = input('give me a word:')
x = reverse(wrd)
if x == wrd:
	print('This is a Palindrome')
else:
	print('This is NOT a Palindrome')