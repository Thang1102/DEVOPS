#!/usr/bin/python3
import random

a = random.sample(range(5,30),10)
b = random.sample(range(1,30),12)
new_list_overlap=[i for i in a if i in b]
print(new_list_overlap)